import { ICartItem } from './cartItem.model';

export interface ICart {
    items: ICartItem[];
    buyerId: string;
}
