export interface IPager {
    itemsPage: number;
    totalItems: number;
    actualPage: number;
    totalPages: number;
    items: number;
}
