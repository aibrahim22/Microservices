export interface ICatalogBrand {
    id: number;
    brand: string;
}