export interface ICatalogType {
    id: number;
    type: string;
}