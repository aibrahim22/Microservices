import { NgModule, ModuleWithProviders }                     from '@angular/core';
import { BrowserModule  }               from '@angular/platform-browser';

import { SharedModule }                 from '../shared/shared.module';
import { CartComponent }              from './cart.component';
import { CartStatusComponent }        from './cart-status/cart-status.component';
import { CartService }                from './cart.service';
import { Header }                from '../shared/components/header/header';

@NgModule({
    imports: [SharedModule],
    declarations: [CartComponent, CartStatusComponent],
    providers: [CartService],
    exports: [CartStatusComponent]
})
export class CartModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: CartModule,
            providers: [
                // Providers
                CartService
            ]
        };
    }
}
