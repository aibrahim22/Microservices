import { Component, OnInit }    from '@angular/core';
import { Subscription }         from 'rxjs';

import { CartService }        from '../cart.service';
import { CartWrapperService } from '../../shared/services/cart.wrapper.service';
import { SecurityService }      from '../../shared/services/security.service';
import { ConfigurationService }      from '../../shared/services/configuration.service';

@Component({
    selector: 'esh-cart-status',
    styleUrls: ['./cart-status.component.scss'],
    templateUrl: './cart-status.component.html'
})
export class CartStatusComponent implements OnInit {
    cartItemAddedSubscription: Subscription;
    authSubscription: Subscription;
    cartDroppedSubscription: Subscription;

    badge: number = 0;

    constructor(private service: CartService, private cartEvents: CartWrapperService, private authService: SecurityService, private configurationService: ConfigurationService) { }

    ngOnInit() {
        // Subscribe to Add Cart Observable:
        this.cartItemAddedSubscription = this.cartEvents.addItemToCart$.subscribe(
            item => {
                this.service.addItemToCart(item).subscribe(res => {
                    this.service.getCart().subscribe(cart => {
                        if (cart)
                            this.badge = cart.items.length;
                    });
                });
            });

        // Subscribe to Drop Cart Observable: 
        this.cartDroppedSubscription = this.service.cartDroped$.subscribe(res => {
            this.badge = 0;
        });

        // Subscribe to login and logout observable
        this.authSubscription = this.authService.authenticationChallenge$.subscribe(res => {
            this.service.getCart().subscribe(cart => {
                if (cart != null)
                    this.badge = cart.items.length;
            });
        });

        // Init:
        if (this.configurationService.isReady) {
            this.service.getCart().subscribe(cart => {
                if (cart != null)
                    this.badge = cart.items.length;
            });
        } else {
            this.configurationService.settingsLoaded$.subscribe(x => {
                this.service.getCart().subscribe(cart => {
                    if (cart != null)
                        this.badge = cart.items.length;
                });
            });
        }
    }
}

