import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Router } from '@angular/router';

import { DataService } from '../shared/services/data.service';
import { SecurityService } from '../shared/services/security.service';
import { ICart } from '../shared/models/cart.model';
import { ICartCheckout } from '../shared/models/cartCheckout.model';
import { CartWrapperService } from '../shared/services/cart.wrapper.service';
import { ConfigurationService } from '../shared/services/configuration.service';
import { StorageService } from '../shared/services/storage.service';

import { Observable, Observer, Subject } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';

@Injectable()
export class CartService {
    private cartUrl: string = '';
    private purchaseUrl: string = '';
    cart: ICart = {
        buyerId: '',
        items: []
    };

    //observable that is fired when the cart is dropped
    private cartDropedSource = new Subject();
    cartDroped$ = this.cartDropedSource.asObservable();

    constructor(private service: DataService, private authService: SecurityService, private cartEvents: CartWrapperService, private router: Router, private configurationService: ConfigurationService, private storageService: StorageService) {
        this.cart.items = [];

        // Init:
        if (this.authService.IsAuthorized) {
            if (this.authService.UserData) {
                this.cart.buyerId = this.authService.UserData.sub;
                if (this.configurationService.isReady) {
                    this.cartUrl = this.configurationService.serverSettings.purchaseUrl;
                    this.purchaseUrl = this.configurationService.serverSettings.purchaseUrl;
                    this.loadData();
                }
                else {
                    this.configurationService.settingsLoaded$.subscribe(x => {
                        this.cartUrl = this.configurationService.serverSettings.purchaseUrl;
                        this.purchaseUrl = this.configurationService.serverSettings.purchaseUrl;
                        this.loadData();
                    });
                }
            }
        }

        this.cartEvents.orderCreated$.subscribe(x => {
            this.dropCart();
        });
    }

    addItemToCart(item): Observable<boolean> {
        this.cart.items.push(item);
        return this.setCart(this.cart);
    }

    setCart(cart): Observable<boolean> {
        let url = this.purchaseUrl + '/api/v1/cart/';

        this.cart = cart;

        return this.service.post(url, cart).pipe<boolean>(tap((response: any) => true));
    }

    setCartCheckout(cartCheckout): Observable<boolean> {
        let url = this.cartUrl + '/b/api/v1/cart/checkout';

        return this.service.postWithId(url, cartCheckout).pipe<boolean>(tap((response: any) => {
            this.cartEvents.orderCreated();
            return true;
        }));
    }

    getCart(): Observable<ICart> {
        let url = this.cartUrl + '/b/api/v1/cart/' + this.cart.buyerId;

        return this.service.get(url).pipe<ICart>(tap((response: any) => {
            if (response.status === 204) {
                return null;
            }

            return response;
        }));
    }

    dropCart() {
        this.cart.items = [];
        this.cartDropedSource.next();
    }

    private loadData() {
        this.getCart().subscribe(cart => {
            if (cart != null)
                this.cart.items = cart.items;
        });
    }
}