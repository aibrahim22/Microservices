import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Observable } from 'rxjs';

import { CartService } from './cart.service';
import { ICart } from '../shared/models/cart.model';
import { ICartItem } from '../shared/models/cartItem.model';
import { CartWrapperService } from '../shared/services/cart.wrapper.service';

@Component({
    selector: 'esh-cart',
    styleUrls: ['./cart.component.scss'],
    templateUrl: './cart.component.html'
})
export class CartComponent implements OnInit {
    errorMessages: any;
    cart: ICart;
    totalPrice: number = 0;

    constructor(private service: CartService, private router: Router, private cartwrapper: CartWrapperService) { }

    ngOnInit() {
        this.service.getCart().subscribe(cart => {
            this.cart = cart;
            this.calculateTotalPrice();
        });
    }

    itemQuantityChanged(item: ICartItem) {
        this.calculateTotalPrice();
        this.service.setCart(this.cart).subscribe(x => console.log('cart updated: ' + x));
    }

    update(event: any): Observable<boolean> {
        let setCartObservable = this.service.setCart(this.cart);
        setCartObservable
            .subscribe(
            x => {
                this.errorMessages = [];
                console.log('cart updated: ' + x);
            },
            errMessage => this.errorMessages = errMessage.messages);
        return setCartObservable;
    }

    checkOut(event: any) {
        this.update(event)
            .subscribe(
                x => {
                    this.errorMessages = [];
                    this.cartwrapper.cart = this.cart;
                    this.router.navigate(['order']);
        });
    }

    private calculateTotalPrice() {
        this.totalPrice = 0;
        this.cart.items.forEach(item => {
            this.totalPrice += (item.unitPrice * item.quantity);
        });
    }
}
