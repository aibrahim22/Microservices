﻿namespace Services.Catalog.API.Model
{
    public class CatalogBrand
    {
        public int Id { get; set; }

        public string Brand { get; set; }
    }
}
