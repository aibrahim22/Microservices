﻿namespace Services.Cart.API
{
    public class CartSettings
    {
        public string ConnectionString { get; set; }
    }
}
