﻿using Cart.API.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Services.Cart.API.Model;
using Services.Cart.API.Services;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Services.Cart.API.Controllers
{
    [Route("api/v1/[controller]")]
    [Authorize]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartRepository _repository;
        private readonly IIdentityService _identityService;
        private readonly ILogger<CartController> _logger;

        public CartController(
            ILogger<CartController> logger,
            ICartRepository repository,
            IIdentityService identityService)
        {
            _logger = logger;
            _repository = repository;
            _identityService = identityService;
        }

        [HttpGet("{id}")]
        [ProducesResponseType(typeof(CustomerCart), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<CustomerCart>> GetCartByIdAsync(string id)
        {
            var cart = await _repository.GetCartAsync(id);

            return Ok(cart ?? new CustomerCart(id));
        }

        [HttpPost]
        [ProducesResponseType(typeof(CustomerCart), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<CustomerCart>> UpdateCartAsync([FromBody]CustomerCart value)
        {
            return Ok(await _repository.UpdateCartAsync(value));
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [ProducesResponseType(typeof(void), (int)HttpStatusCode.OK)]
        public async Task DeleteCartByIdAsync(string id)
        {
            await _repository.DeleteCartAsync(id);
        }
    }
}
