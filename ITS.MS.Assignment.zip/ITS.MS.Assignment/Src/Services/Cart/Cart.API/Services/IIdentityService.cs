﻿namespace Services.Cart.API.Services
{
    public interface IIdentityService
    {
        string GetUserIdentity();
    }
}
