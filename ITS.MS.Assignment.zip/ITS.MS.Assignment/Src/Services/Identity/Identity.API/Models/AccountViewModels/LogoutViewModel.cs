﻿namespace Services.Identity.API.Models.AccountViewModels
{
    public class LogoutViewModel
    {
        public string LogoutId { get; set; }
    }
}